package com.example.flutter_chat_box

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
